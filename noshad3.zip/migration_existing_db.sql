-- فقط برای پایگاه داده‌ای که قبلاً ساخته شده است اجرا شود.
-- اگر branch_name از قبل وجود دارد، خط اول را رد کنید.
ALTER TABLE classes ADD COLUMN branch_name VARCHAR(100) NULL;
CREATE TABLE IF NOT EXISTS school_staff (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 position_title VARCHAR(150) NOT NULL,
 bio VARCHAR(600) NULL,
 display_order INT NOT NULL DEFAULT 0,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
